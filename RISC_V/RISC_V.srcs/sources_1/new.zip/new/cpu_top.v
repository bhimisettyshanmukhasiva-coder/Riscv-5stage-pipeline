module cpu_top(
    input clk,
    input reset,

    // Debug Outputs
    output [31:0] pc_if,
    output [31:0] instruction_if,
    output [31:0] alu_result_wb_out
);

// ==========================
// Internal Wires
// ==========================

// IF stage
wire [31:0] pc_if_w;
wire [31:0] instruction_if_w;

// IF/ID
wire [31:0] pc_id_w;
wire [31:0] instruction_id_w;

// Decode
wire [6:0]  opcode_w;
wire [4:0]  rd_w;
wire [2:0]  funct3_w;
wire [4:0]  rs1_w;
wire [4:0]  rs2_w;
wire [6:0]  funct7_w;

// Register File
wire [31:0] read_data1_w;
wire [31:0] read_data2_w;

// ? NEW: Immediate + Control
wire [31:0] imm_w;
wire [31:0] imm_ex;
wire alu_src_ctrl;
wire alu_src_ex;

// ID/EX
wire [31:0] read_data1_ex;
wire [31:0] read_data2_ex;
wire [2:0]  funct3_ex;
wire [6:0]  funct7_ex;
wire [6:0]  opcode_ex;
wire [4:0]  rd_ex;

// Control signals
wire reg_write_ctrl;
wire mem_read_ctrl;
wire mem_write_ctrl;

wire reg_write_ex;
wire mem_read_ex;
wire mem_write_ex;

wire reg_write_mem;
wire mem_read_mem;
wire mem_write_mem;

// EX
wire [31:0] alu_result_ex;

// ? NEW: ALU MUX output
wire [31:0] operand2_final;

// EX/MEM
wire [31:0] alu_result_mem;
wire [4:0]  rd_mem;
wire [31:0] write_data_mem;

// MEM
wire [31:0] mem_read_data;

// MEM/WB
wire [31:0] alu_result_wb;
wire [4:0]  rd_wb;
wire        reg_write_wb;


// ==========================
// IF Stage
// ==========================

pc pc_inst(
    .clk(clk),
    .reset(reset),
    .pc_out(pc_if_w)
);

instruction_memory imem_inst(
    .addr(pc_if_w),
    .instruction(instruction_if_w)
);


// ==========================
// IF/ID
// ==========================

if_id if_id_inst(
    .clk(clk),
    .reset(reset),
    .pc_in(pc_if_w),
    .instruction_in(instruction_if_w),
    .pc_out(pc_id_w),
    .instruction_out(instruction_id_w)
);


// ==========================
// ID Stage
// ==========================

instruction_decode id_inst(
    .instruction(instruction_id_w),
    .opcode(opcode_w),
    .rd(rd_w),
    .funct3(funct3_w),
    .rs1(rs1_w),
    .rs2(rs2_w),
    .funct7(funct7_w)
);

// ? Immediate Generation
assign imm_w = {{20{instruction_id_w[31]}}, instruction_id_w[31:20]};

// Control Unit
control_unit cu_inst(
    .opcode(opcode_w),
    .reg_write(reg_write_ctrl),
    .mem_read(mem_read_ctrl),
    .mem_write(mem_write_ctrl),
    .alu_src(alu_src_ctrl)   // ? ADDED
);


// Register File
register_file rf_inst(
    .clk(clk),
    .reset(reset),
    .rs1(rs1_w),
    .rs2(rs2_w),
    .rd(rd_wb),
    .write_data(alu_result_wb),
    .reg_write(reg_write_wb),
    .read_data1(read_data1_w),
    .read_data2(read_data2_w)
);


// ==========================
// ID/EX
// ==========================

id_ex id_ex_inst(
    .clk(clk),
    .reset(reset),

    .read_data1_in(read_data1_w),
    .read_data2_in(read_data2_w),
    .imm_in(imm_w),              // ? ADDED

    .funct3_in(funct3_w),
    .funct7_in(funct7_w),
    .opcode_in(opcode_w),
    .rd_in(rd_w),

    .alu_src_in(alu_src_ctrl),   // ? ADDED

    .reg_write_in(reg_write_ctrl),
    .mem_read_in(mem_read_ctrl),
    .mem_write_in(mem_write_ctrl),

    .read_data1_out(read_data1_ex),
    .read_data2_out(read_data2_ex),
    .imm_out(imm_ex),            // ? ADDED

    .funct3_out(funct3_ex),
    .funct7_out(funct7_ex),
    .opcode_out(opcode_ex),
    .rd_out(rd_ex),

    .alu_src_out(alu_src_ex),    // ? ADDED

    .reg_write_out(reg_write_ex),
    .mem_read_out(mem_read_ex),
    .mem_write_out(mem_write_ex)
);


// ==========================
// EX Stage
// ==========================

// ? MUX for operand2
assign operand2_final = (alu_src_ex) ? imm_ex : read_data2_ex;

alu alu_inst(
    .operand1(read_data1_ex),
    .operand2(operand2_final),   // ? FIXED
    .funct3(funct3_ex),
    .funct7(funct7_ex),
    .opcode(opcode_ex),
    .alu_result(alu_result_ex)
);


// ==========================
// EX/MEM
// ==========================

ex_mem ex_mem_inst(
    .clk(clk),
    .reset(reset),

    .alu_result_in(alu_result_ex),
    .rd_in(rd_ex),
    .write_data_in(read_data2_ex),

    .reg_write_in(reg_write_ex),
    .mem_read_in(mem_read_ex),
    .mem_write_in(mem_write_ex),

    .alu_result_out(alu_result_mem),
    .rd_out(rd_mem),
    .write_data_out(write_data_mem),

    .reg_write_out(reg_write_mem),
    .mem_read_out(mem_read_mem),
    .mem_write_out(mem_write_mem)
);


// ==========================
// MEM Stage
// ==========================

data_memory dmem_inst(
    .clk(clk),
    .mem_write(mem_write_mem),
    .mem_read(mem_read_mem),
    .address(alu_result_mem),
    .write_data(write_data_mem),
    .read_data(mem_read_data)
);


// ==========================
// MEM/WB
// ==========================

mem_wb mem_wb_inst(
    .clk(clk),
    .reset(reset),

    .alu_result_in(alu_result_mem),
    .rd_in(rd_mem),

    .reg_write_in(reg_write_mem),

    .alu_result_out(alu_result_wb),
    .rd_out(rd_wb),
    .reg_write_out(reg_write_wb)
);


// ==========================
// Debug Outputs
// ==========================

assign pc_if = pc_if_w;
assign instruction_if = instruction_if_w;
assign alu_result_wb_out = alu_result_wb;

endmodule