module control_unit(
    input  [6:0] opcode,

    output reg reg_write,
    output reg mem_read,
    output reg mem_write,
    output reg alu_src      // IMPORTANT
);

always @(*) begin
    case(opcode)

        7'b0110011: begin   // R-type (ADD)
            reg_write = 1;
            mem_read  = 0;
            mem_write = 0;
            alu_src   = 0;   // use rs2
        end

        7'b0010011: begin   // I-type (ADDI)
            reg_write = 1;
            mem_read  = 0;
            mem_write = 0;
            alu_src   = 1;   // use immediate
        end

        default: begin
            reg_write = 0;
            mem_read  = 0;
            mem_write = 0;
            alu_src   = 0;
        end

    endcase
end

endmodule