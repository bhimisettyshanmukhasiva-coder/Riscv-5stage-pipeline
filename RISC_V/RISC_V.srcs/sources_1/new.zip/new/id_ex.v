module id_ex(
    input clk,
    input reset,

    input  [31:0] read_data1_in,
    input  [31:0] read_data2_in,
    input  [31:0] imm_in,          // ? NEW
    input  [2:0]  funct3_in,
    input  [6:0]  funct7_in,
    input  [6:0]  opcode_in,
    input  [4:0]  rd_in,
    input         alu_src_in,      // ? NEW

    // control signals
    input  reg_write_in,
    input  mem_read_in,
    input  mem_write_in,

    output reg [31:0] read_data1_out,
    output reg [31:0] read_data2_out,
    output reg [31:0] imm_out,     // ? NEW
    output reg [2:0]  funct3_out,
    output reg [6:0]  funct7_out,
    output reg [6:0]  opcode_out,
    output reg [4:0]  rd_out,
    output reg        alu_src_out, // ? NEW

    // control signals
    output reg reg_write_out,
    output reg mem_read_out,
    output reg mem_write_out
);

always @(posedge clk or posedge reset) begin
    if (reset) begin
        read_data1_out <= 0;
        read_data2_out <= 0;
        imm_out        <= 0;   // ? RESET
        funct3_out     <= 0;
        funct7_out     <= 0;
        opcode_out     <= 0;
        rd_out         <= 0;
        alu_src_out    <= 0;   // ? RESET

        // control signals
        reg_write_out <= 0;
        mem_read_out  <= 0;
        mem_write_out <= 0;
    end
    else begin
        read_data1_out <= read_data1_in;
        read_data2_out <= read_data2_in;
        imm_out        <= imm_in;       // ? FIXED
        funct3_out     <= funct3_in;
        funct7_out     <= funct7_in;
        opcode_out     <= opcode_in;
        rd_out         <= rd_in;
        alu_src_out    <= alu_src_in;   // ? FIXED

        // control signals
        reg_write_out <= reg_write_in;
        mem_read_out  <= mem_read_in;
        mem_write_out <= mem_write_in;
    end
end

endmodule