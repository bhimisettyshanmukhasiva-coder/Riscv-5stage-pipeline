module ex_mem(
    input clk,
    input reset,

    // datapath signals
    input  [31:0] alu_result_in,
    input  [4:0]  rd_in,
    input  [31:0] write_data_in,

    // control signals from EX stage
    input  reg_write_in,
    input  mem_read_in,
    input  mem_write_in,

    // datapath outputs
    output reg [31:0] alu_result_out,
    output reg [4:0]  rd_out,
    output reg [31:0] write_data_out,

    // control signals to MEM stage
    output reg reg_write_out,
    output reg mem_read_out,
    output reg mem_write_out
);

always @(posedge clk or posedge reset) begin
    if (reset) begin
        alu_result_out <= 0;
        rd_out <= 0;
        write_data_out <= 0;   // ? IMPORTANT FIX

        // reset control signals
        reg_write_out <= 0;
        mem_read_out  <= 0;
        mem_write_out <= 0;
    end
    else begin
        alu_result_out <= alu_result_in;
        rd_out <= rd_in;
        write_data_out <= write_data_in;

        // pass control signals forward
        reg_write_out <= reg_write_in;
        mem_read_out  <= mem_read_in;
        mem_write_out <= mem_write_in;
    end
end

endmodule